// write a node.js script usign mongoose to perform the following on the courses collection : 
// 1. insert multiple course document
// 2. display the course having highest fees
// 3. find the course name monstack development
// 4.update the fees to rs.15000 and duration to 5 month for the course name monstack development 
//   using find by id and update method
// 5.display all online courses having fees  < 20000
// 6. display all active courses whose duration is > 4 months

const mg = require("mongoose")
mg.connect('mongodb://127.0.0.1:27017/courses')
    .then(() => {console.log("connected")})
    .catch((err) => {console.log(err)})

mg.pluralize(null)

const mySchema = new mg.Schema(
    {
        name : {type : String} , 
        fees : {type : Number}, 
        duration : {type : Number} , 
        type : {type : String},
    } , {strict : false}
)

const course = new mg.model("course" , mySchema)
const createDoc = async() =>{
    try{
        const courseData = [{name : 'python' , fees : 20000 , duration : 4 , type : 'offline'},
            {name : 'python' , fees : 15000 , duration : 5 , type : 'online'},
            {name : 'monstack development' , fees : 15000 , duration : 4 , type : 'offline'},
            {name : 'monstack development' , fees : 20000 , duration : 5 , type : 'online'} 
        ]
        const result = await course.insertMany(courseData)
    }
    catch(err){
        console.log(err)
    }
}
createDoc()

// Unit 9 --> 16 marks , Unit 10 --> 25 marks
// 16 mcq and 25 program
// const result = await movie.insertMany(movieData)