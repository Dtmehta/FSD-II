// Delete

const mg = require("mongoose")
mg.connect('mongodb://127.0.0.1:27017/test')
    .then(() => {console.log("connected")})
    .catch((err) => {console.log(err)})

mg.pluralize(null)

const mySchema = new mg.Schema(
    {
        name : {type : String , required : true , uppercase : true} , 
        password : {type : String , minlength : 6 , maxlength :12}, 
        date : {type : Date , default : new Date()} , 
        age : {type : String},
    } , {strict : false}
)

const person = new mg.model("person" , mySchema)
const deleteDoc = async(i)=> {
    try{
        const result = await person.deleteMany({age : i})
        console.log(result)
    }
    catch(err){
        console.log(err)
    }
}
deleteDoc(20)