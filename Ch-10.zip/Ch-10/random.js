const mg = require('mongoose')
const v = require('validator')
mg.connect("mongodb://127.0.0.1:27017/valid")
const userSchema = new mg.Schema({
    email : {type : String , required : true , unique : true,
        validate : [v.isEmail , 'Enter a valid email']
    },
    product : {type : String , required : true , 
        validate : [v.isAlphanumeric , 'nota valid alpha numeric number']
    }
})
const T1 = mg.model('T1' , userSchema)
const createDoc = async() =>{
    try{
        const n1 = new T1({
            email : "xyz@gmail.com" , product : 'abc123'
        })
        await n1.save()
    }
    catch(err){
        console.log(err)
    }
}
createDoc()