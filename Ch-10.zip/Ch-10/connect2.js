// Find

const mg = require("mongoose")
mg.connect('mongodb://127.0.0.1:27017/test')
    .then(() => {console.log("connected")})
    .catch((err) => {console.log(err)})

mg.pluralize(null)

const mySchema = new mg.Schema(
    {
        name : {type : String , required : true , uppercase : true} , 
        password : {type : String , minlength : 6 , maxlength :12}, 
        date : {type : Date , default : new Date()} , 
        age : {type : String},
    } , {strict : false}
)

const person = new mg.model("person" , mySchema)
const findDoc = async(i)=> {
    try{
        const result = await person.find({_id : i})
        console.log(result)
    }
    catch(err){
        console.log(err)
    }
}
findDoc('6a449fc6e78d8908bfdc3338')