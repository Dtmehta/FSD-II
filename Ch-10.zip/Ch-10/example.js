const mg = require("mongoose")
mg.connect('mongodb://127.0.0.1:27017/test')
    .then(() => {console.log("connected")})
    .catch((err) => {console.log(err)})

mg.pluralize(null)

const mySchema = new mg.Schema(
    {
        title : {type : String , required : true} , 
        type : {type : String}, 
        rating : {type : Number} , 
        language : {type : String},
    } , {strict : false}
)

const movie = new mg.model("movie" , mySchema)
// const createDoc = async() =>{
//     try{
//         const movieData = [{title : '3 idiots' , type : 'romantic' , rating : 8.5 , language : 'hindi'},
//             {title : 'krish3' , type : 'action' , rating : 8 , language : 'english'},
//             {title : 'chello divas' , type : 'comady' , rating : 9 , language : 'gujarati'},
//             {title : 'cocktail' , type : 'romantic' , rating : 5.6 , language : 'hindi'}
//         ]
//         const result = await movie.insertMany(movieData)
//     }
//     catch(err){
//         console.log(err)
//     }
// }

const performOperations = async() =>{
    try{
        console.log(await movie.find({rating : {$gt : 8.5}}))
        console.log(await movie.find({} , {title : 1 , rating : 1 , _id : 0}).sort({rating : -1}).skip(1).limit(1))
        console.log(await movie.updateMany({type : 'action'}, {$inc : {rating : 0.2}}))
        console.log(await movie.find({language : 'hindi'}).count())
        console.log(await movie.deleteOne({title : '3 idiots'}))
    }
    catch(err){
        console.log(err)
    }
}
performOperations()
// createDoc()
// write a node js script using mongoosh to perform the follwing function on movie collections
// 1. insert multiple movie documents
// 2. display all movies having rationg  < 8.5
// 3. display the title and rating of the movie having the second highest rating
// 4. increase the rating of all action movie by 0.2
// 5. count a total no of hindi movie
// 6. delete the movie having the title 3 idiot