// html,css  + Express + mongoDB

var expr = require('express')
var app = expr()
const mg = require('mongoose')
mg.connect("mongodb://127.0.0.1:27017/login1")
.then(() => {console.log("Connected")})
.catch((err) => {console.log(err)})

mg.pluralize(null)
const userSchema = new mg.Schema({
    uname : {type : String , required : true},
    password : String
})
const Login = new mg.model("data1" , userSchema)
app.use(expr.static(__dirname , {index : 'form.html'}))

app.get("/process_get" , async(req,res) =>{
    const p1 = new Login({
        uname : req.query.uname,
        password : req.query.pwd
    })
    await p1.save()
    res.send("Record inserted")
}).listen(5001)