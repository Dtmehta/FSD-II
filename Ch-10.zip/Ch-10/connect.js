const mg = require("mongoose")
mg.connect('mongodb://127.0.0.1:27017/test')
    .then(() => {console.log("connected")})
    .catch((err) => {console.log(err)})

mg.pluralize(null)
// Define Schema
const mySchema = new mg.Schema(
    {
        name : {type : String , required : true , uppercase : true} , 
        password : {type : String , minlength : 6 , maxlength :12}, 
        date : {type : Date , default : new Date()}
    } , {strict : false}
)

// model
const person = new mg.model("person" , mySchema)
const createDoc = async()=> {
    try{
        const personData =new person ({name : 'abc' , password : 'xyz1234'})
        await personData.save()
    }
    catch(err){
        console.log(err)
    }
}
createDoc()

// define a user schema as below 
// 1. username - required , must be between 4 and 20 char. long , must starts with latters and end with digit ,
//   should be trim  of any leading and traling spaces , should be converted to uppercase before saving
// 2. Email - required , must be unique and must follow the email formet
// 3. age - must be between 18 and 65
// 4. role - must be either user or admin and should default to user if not provided
// ANSWER :- 
// const mySchema = new mg.Schema ({ 
//          username : {type : String , required : [true , "username is required"] , 
//                      minlength : [4 , 'must be atleast 4 char. long'] , maxlength : 20 , match : /^[A-Za-z]+[0-9]+$/ ,
//                      trim : true} , uppercase : true}) , 
//          Email : {type : String , required : true , unique : true , match : /\S+@\S+\.\S+/} , 
//          age : {type : Number , minlength : 18 , maxlength : 65} , 
//          role : {type : String , enum : ['user' , 'admin'] , default : 'user' } })